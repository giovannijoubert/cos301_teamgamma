function sendReq() {

    para.innerText="Multiple Request TEST:"+"\n\n";

    for (let i=0;i<24;i++) {
        let req = new XMLHttpRequest();
        req.open("POST", "sharingapi.php", true);
        let obj = {requestType: "getMouthPack", id: i};
        let myJSON = JSON.stringify(obj);
        req.setRequestHeader("Content-type", "application/json")
        req.send(myJSON);
        req.onreadystatechange = function () {
            if (req.readyState == 4 && req.status == 200) {
                let res = req.responseText;
                let para =document.getElementById("para");
                para.innerText+=res+"\n";
            }

        }
    }
}

function getAll()
{
    let para =document.getElementById("para");

    para.innerText="GetAll:";

    for (let i=0;i<2;i++)
    {
        para.innerText+="\n";
    }

    let req = new XMLHttpRequest();
    req.open("POST", "sharingapi.php", true);
    let obj = {requestType : "getAllMouthpacks"};
    let myJSON = JSON.stringify(obj);
    req.setRequestHeader("Content-type", "application/json")
    req.send(myJSON);
    req.onreadystatechange = function () {
        if (req.readyState == 4 && req.status == 200) {
            let res = req.responseText;
            let para =document.getElementById("para");
            para.innerText+=res+"\n";
        }

    }
}

function filteredGetAll()
{

    let para =document.getElementById("para");

    para.innerText="FilteredGetAll:";

    for (let i=0;i<2;i++)
    {
        para.innerText+="\n";
    }

    let req = new XMLHttpRequest();
    req.open("POST", "sharingapi.php", true);
    let obj = {
requestType : "getAllMouthpacks",
filter : {
criteria : "mouthpack_name",
like : "vampire"
},
sort_by : "mouthpack_id",
order : "desc"
};
    let myJSON = JSON.stringify(obj);
    req.setRequestHeader("Content-type", "application/json")
    req.send(myJSON);
    req.onreadystatechange = function () {
        if (req.readyState == 4 && req.status == 200) {
            let res = req.responseText;
            let para =document.getElementById("para");
            para.innerText+=res+"\n";
        }

    }
}