function sendReq() {

    para.innerText="Multiple Request TEST: for ID 1128226672, ID 1884622625, ID 0"+"\n\n";

        let req = new XMLHttpRequest();
        req.open("POST", "sharingapi.php", true);
        let obj = {requestType: "getMouthPack", id: 1128226672};
        let myJSON = JSON.stringify(obj);
        req.setRequestHeader("Content-type", "application/json")
        req.send(myJSON);
        req.onreadystatechange = function () {
            if (req.readyState == 4 && req.status == 200) {
                let res = req.responseText;
                let para = document.getElementById("para");
                para.innerText += res + "\n\n";
            }

        }

    let req2 = new XMLHttpRequest();
    req2.open("POST", "sharingapi.php", true);
    let obj2 = {requestType: "getMouthPack", id: 1884622625};
    let myJSON2 = JSON.stringify(obj2);
    req2.setRequestHeader("Content-type", "application/json")
    req2.send(myJSON2);
    req2.onreadystatechange = function () {
        if (req2.readyState == 4 && req2.status == 200) {
            let res = req2.responseText;
            let para = document.getElementById("para");
            para.innerText += res + "\n\n";
        }

    }

    let req3 = new XMLHttpRequest();
    req3.open("POST", "sharingapi.php", true);
    let obj3 = {requestType: "getMouthPack", id: 0};
    let myJSON3 = JSON.stringify(obj3);
    req3.setRequestHeader("Content-type", "application/json")
    req3.send(myJSON3);
    req3.onreadystatechange = function () {
        if (req3.readyState == 4 && req3.status == 200) {
            let res = req3.responseText;
            let para = document.getElementById("para");
            para.innerText += res + "\n\n";
        }

    }
}

function getAll()
{
    let para =document.getElementById("para");

    para.innerText="GetAll:";

    for (let i=0;i<2;i++)
    {
        para.innerText+="\n";
    }

    let req = new XMLHttpRequest();
    req.open("POST", "sharingapi.php", true);
    let obj = {requestType : "getAllMouthpacks"};
    let myJSON = JSON.stringify(obj);
    req.setRequestHeader("Content-type", "application/json")
    req.send(myJSON);
    req.onreadystatechange = function () {
        if (req.readyState == 4 && req.status == 200) {
            let res = req.responseText;
            let para =document.getElementById("para");
            para.innerText+=res+"\n\n";
        }

    }
}

function filteredGetAll()
{

    let para =document.getElementById("para");

    para.innerText="FilteredGetAll: Where any Mouthpack name includes 'Mouthpack' sorted in descending order by ID";

    for (let i=0;i<2;i++)
    {
        para.innerText+="\n";
    }

    let req = new XMLHttpRequest();
    req.open("POST", "sharingapi.php", true);
    let obj = {
requestType : "getAllMouthpacks",
filter : {
criteria : "mouthpack_name",
like : "Mouthpack"
},
sort_by : "mouthpack_id",
order : "desc"
};
    let myJSON = JSON.stringify(obj);
    req.setRequestHeader("Content-type", "application/json")
    req.send(myJSON);
    req.onreadystatechange = function () {
        if (req.readyState == 4 && req.status == 200) {
            let res = req.responseText;
            let para =document.getElementById("para");
            para.innerText+=res+"\n\n";
        }

    }
}

function getCategories()
{
    let para =document.getElementById("para");

    para.innerText="GetCategory: Scary";

    for (let i=0;i<2;i++)
    {
        para.innerText+="\n";
    }

    let req = new XMLHttpRequest();
    req.open("POST", "sharingapi.php", true);
    let obj = {
        requestType : "getMouthpacksByCategory",
        category : "Scary"
    };
    let myJSON = JSON.stringify(obj);
    req.setRequestHeader("Content-type", "application/json")
    req.send(myJSON);
    req.onreadystatechange = function () {
        if (req.readyState == 4 && req.status == 200) {
            let res = req.responseText;
            let para =document.getElementById("para");
            para.innerText+=res+"\n";
        }

    }
}