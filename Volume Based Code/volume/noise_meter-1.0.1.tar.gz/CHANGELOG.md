## 0.1.1
* fix of issue [#22](https://github.com/cph-cachet/flutter-plugins/issues/22) (UIThread exception in Android)

## 0.1.0
* Initial release.
