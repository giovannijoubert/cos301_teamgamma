# noise_meter_example

Demonstrates how to use the noise_meter plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
