#import <Flutter/Flutter.h>

@interface NoiseMeterPlugin : NSObject<FlutterPlugin>
@end
