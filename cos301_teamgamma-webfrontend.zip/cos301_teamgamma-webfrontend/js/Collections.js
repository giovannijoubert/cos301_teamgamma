$(document).ready(function(){

  $("#delete1").click(function(){
var checkstr =  confirm('are you sure you want to delete this?');
if(checkstr == true){

   $("#div1").remove();
}else{
return false;
}
});
    $("#delete2").click(function(){
var checkstr =  confirm('are you sure you want to delete this?');
if(checkstr == true){

   $("#div2").remove();
}else{
return false;
}
});
      $("#delete3").click(function(){
var checkstr =  confirm('are you sure you want to delete this?');
if(checkstr == true){

   $("#div3").remove();
}else{
return false;
}
});
        $("#delet4").click(function(){
var checkstr =  confirm('are you sure you want to delete this?');
if(checkstr == true){

   $("#div4").remove();
}else{
return false;
}
});
          $("#delete5").click(function(){
var checkstr =  confirm('are you sure you want to delete this?');
if(checkstr == true){

   $("#div5").remove();
}else{
return false;
}
});
            $("#delete").click(function(){
var checkstr =  confirm('are you sure you want to delete this?');
if(checkstr == true){

   $("#div1").remove();
}else{
return false;
}
});
  
});